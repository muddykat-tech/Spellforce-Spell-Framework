This archive contains all assets (models, textures, animations, edited original scripts) necessary to add custom building (Dwarf Tower) to Spellforce Platinum Edition.

All files except for dwarf_tower_dependency.cff are presented as they should exist within the game folder. Extract the archive to Spellforce folder and confirm merging requests for subfolders if there would be any.

In order to find out how to merge dwarf_tower_dependency please read this guide:

https://github.com/muddykat-tech/Spellforce-Spell-Framework/wiki/Chapter-6.2:-Creating-Custom-Building#using-gamedata-merge
